Developed on Ubuntu with QtCreator. Please use "make" in one of the build-* folders.
